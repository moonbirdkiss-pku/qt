#ifndef STORE_H
#define STORE_H

#include <QDialog>

namespace Ui {
class Store;
}

class Store : public QDialog
{
    Q_OBJECT

public:
    explicit Store(QWidget *parent = nullptr);
    void send_score(int data);
    void send_life(int data);
    void send_life_max(int data);
    void send_bomb_total(int data);
    void send_freeze_total(int data);
    void set_price();
    int difficulty = 0;
    int score = 0;
    int life_max = 5;
    int life = 5;
    int bomb_total = 0;
    int freeze_total = 0;
    ~Store();
    int HPrecoverporp_price;
    int HPplusprop_price;
    int freeze_price;
    int bomb_price;

private slots:

    void on_contiueButtonC_clicked();

    void on_HPpluspropButtonC_clicked();

    void on_HPrecoverypropButtonC_clicked();

    void on_saveButton_clicked();

    ;void on_freezepriceButton_clicked();

private:
    Ui::Store *ui;

};

#endif // STORE_H
