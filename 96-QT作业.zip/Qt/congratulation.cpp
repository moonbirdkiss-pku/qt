#include "congratulation.h"
#include "ui_congratulation.h"
#include"mainmenu.h"

Congratulation::Congratulation(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Congratulation)
{
    ui->setupUi(this);
}

Congratulation::~Congratulation()
{
    delete ui;
}

void Congratulation::on_pushButton_clicked()
{
    MainMenu *mm=new MainMenu();
    mm->show();
    this->close();
}

