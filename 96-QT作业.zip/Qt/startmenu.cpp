#include "startmenu.h"
#include "ui_startmenu.h"
#include "mainmenu.h"
#include "ui_mainmenu.h"
#include"mainmenu_eng.h"

startMenu::startMenu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::startMenu)
{
    ui->setupUi(this);
}

startMenu::~startMenu()
{
    delete ui;
}

void startMenu::on_englishButton_clicked()
{
    this->hide();
    MainMenu_eng *e = new MainMenu_eng();
    e->show();
}



void startMenu::on_chineseButton_clicked()
{
    this->hide();
    MainMenu *chi = new MainMenu();
    chi->show();
}

