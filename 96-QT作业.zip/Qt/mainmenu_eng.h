#ifndef MAINMENU_ENG_H
#define MAINMENU_ENG_H

#include <QDialog>

namespace Ui {
class MainMenu_eng;
}

class MainMenu_eng : public QDialog
{
    Q_OBJECT

public:
    explicit MainMenu_eng(QWidget *parent = nullptr);
    ~MainMenu_eng();

private slots:
    void on_pushButton_2_clicked();

private:
    Ui::MainMenu_eng *ui;
};

#endif // MAINMENU_ENG_H
