#include "explain_operation.h"
#include "ui_explain_operation.h"
#include "mainmenu.h"
#include "explain.h"
#include "ui_explain.h"

Explain_Operation::Explain_Operation(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Explain_Operation)
{
    ui->setupUi(this);
}

Explain_Operation::~Explain_Operation()
{
    delete ui;
}

void Explain_Operation::keyPressEvent(QKeyEvent *event){
    if((event->modifiers()& Qt::ControlModifier) != 0 && event->key()==Qt::Key_B){//Exit (这个功能直接esc 是一样的)返回
        this->close();
        MainMenu *mm = new MainMenu;
        mm->show();

    }
}

void Explain_Operation::on_returnButtonC_clicked()
{
    this->close();
    Explain *e=new Explain();
    e->show();
}

