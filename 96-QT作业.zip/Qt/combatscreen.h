#ifndef COMBATSCREEN_H
#define COMBATSCREEN_H

#include <QDialog>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QTime>
#include <QTimer>
#include <QVector>
#include <QFont>
#include "target.h"

namespace Ui {
class CombatScreen;
}

class CombatScreen : public QDialog
{
    Q_OBJECT

public:
    explicit CombatScreen(QWidget *parent = nullptr);
    ~CombatScreen();
    void score_increase();
    void score_decrease();
    void life_decrease();
    void isWin();
    void send_score(int data);
    void send_life(int data);
    void send_life_max(int data);
    void send_bomb_total(int data);
    void send_freeze_total(int data);
    int score=0;
    int life=5;
    int life_max=5;
    int bomb_total=0;
    int freeze_total=2;
    int score_0=5;
    bool dotrick=true;
    target *ikun;
    QVector<target*> IKUNS;
    void pause_restart();
    void pause_restart_1();



private:
    void keyPressEvent(QKeyEvent *event);

private slots:
    void on_pauseButtonC_clicked();
    void on_bombButton_clicked();
    void on_freezeButton_clicked();
    void build_kun();
    void updatetime();
    //void tricktime1();

    void on_playButtonC_clicked();

    void on_trickButton1C_clicked();

    void on_trickButton2C_clicked();

private:
    Ui::CombatScreen *ui;
    QPoint dot;
    QTimer *sure;
    QTimer *time_1;
    QTimer tricktimer;
    QTime tricktime;
    QTimer timer;
    QTime time;

};

#endif // COMBATSCREEN_H

