#ifndef STARTMENU_H
#define STARTMENU_H

#include <QDialog>


namespace Ui {
class startMenu;
}

class startMenu : public QDialog
{
    Q_OBJECT

public:
    explicit startMenu(QWidget *parent = nullptr);
    ~startMenu();

private slots:
    void on_englishButton_clicked();

    void on_chineseButton_clicked();

private:
    Ui::startMenu *ui;
};

#endif // STARTMENU_H
