#ifndef CONGRATULATION_H
#define CONGRATULATION_H

#include <QDialog>

namespace Ui {
class Congratulation;
}

class Congratulation : public QDialog
{
    Q_OBJECT

public:
    explicit Congratulation(QWidget *parent = nullptr);
    ~Congratulation();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Congratulation *ui;
};

#endif // CONGRATULATION_H
