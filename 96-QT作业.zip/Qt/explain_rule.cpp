#include "explain_rule.h"
#include "ui_explain_rule.h"
#include "mainmenu.h"
#include "explain.h"
#include "ui_explain.h"

Explain_Rule::Explain_Rule(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Explain_Rule)
{
    ui->setupUi(this);
}

Explain_Rule::~Explain_Rule()
{
    delete ui;
}

void Explain_Rule::on_returnButtonC_clicked()
{
    this->close();
    Explain *e=new Explain();
    e->show();
}

