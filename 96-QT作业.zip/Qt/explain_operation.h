#ifndef EXPLAIN_OPERATION_H
#define EXPLAIN_OPERATION_H

#include <QDialog>

namespace Ui {
class Explain_Operation;
}

class Explain_Operation : public QDialog
{
    Q_OBJECT

public:
    explicit Explain_Operation(QWidget *parent = nullptr);
    ~Explain_Operation();

private slots:
    void on_returnButtonC_clicked();

private:
    void keyPressEvent(QKeyEvent *event);
    Ui::Explain_Operation *ui;
};

#endif // EXPLAIN_OPERATION_H
