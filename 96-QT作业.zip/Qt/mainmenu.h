#ifndef MAINMENU_H
#define MAINMENU_H

#include <QDialog>
#include <QKeyEvent>

namespace Ui {
class MainMenu;
}

class MainMenu : public QDialog
{
    Q_OBJECT

public:
    explicit MainMenu(QWidget *parent = nullptr);
    ~MainMenu();

private:
    void keyPressEvent(QKeyEvent *event);

private slots:
    void on_startButtonC_clicked();

    void on_saveButtonC_clicked();

    void on_introButtonC_clicked();

    void on_exitButtonC_clicked();

    void on_returnButtonC_clicked();

private:
    Ui::MainMenu *ui;
};

#endif // MAINMENU_H
