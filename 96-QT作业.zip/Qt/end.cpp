#include "end.h"
#include "ui_end.h"
#include "mainmenu.h"
#include "combatscreen.h"
extern int difficulty;
End::End(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::End)
{
    ui->setupUi(this);
    //CombatScreen *com = new CombatScreen;
    //connect(com, SIGNAL(send_score(int)), this, SLOT(receive_score(int)));
}

End::~End()
{
    delete ui;
}

void End::on_returnButtonC_clicked()
{
    this->close();
    difficulty=-1;
    MainMenu *mm=new MainMenu();
    mm->show();
}

void End::send_score(int data)
{
    ui->scorelabel->setText(QString::number(data));
}

