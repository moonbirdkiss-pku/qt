#include "combatscreen.h"
#include "ui_combatscreen.h"
#include "pause.h"
#include<QLabel>
#include<QTimer>
#include <QVector>
#include <QFont>
#include "end.h"
#include "store.h"
#include "congratulation.h"
#include "ui_store.h"
#include "ui_end.h"
int difficulty=-1;

CombatScreen::CombatScreen(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CombatScreen)
{
    if(difficulty<3)difficulty+=1;
    ui->setupUi(this);
    //靶子
    ui->lifelabel->setText(QString::number(life));
    time_1 = new QTimer();
    connect(time_1,SIGNAL(timeout()),this,SLOT(build_kun()));

    if(difficulty == 0){time_1->start(500);score_0=40;}
    if(difficulty == 1){time_1->start(400);score_0=60;}
    if(difficulty == 2){time_1->start(300);score_0=90;}
    if(difficulty == 3){time_1->start(300);score_0=120;}
    //QFont f("仿宋",16);
    ui->aimscorelabel->setText(QString::number(score_0));
    //ui->aimscorelabel->setFont(f);

    //定时器
    connect(&timer,SIGNAL(timeout()),this,SLOT(updatetime()));
    time.setHMS(0,0,30,0);
    ui->timelabel->setText("00:00:30:000");
    timer.start(40);
    if(time.toString("hh:mm:ss:zzz")=="00:00:00:000"){
        timer.stop();
    }

    //sure = new QTimer();
    //connect(sure,SIGNAL(timeout()),this,SLOT(sure()));
    //sure->start(1000);

}
//定时器
void CombatScreen::updatetime(){
    ui->difficultylabel->setText(QString::number(difficulty+1));
    ui->life_maxlabel->setText(QString::number(life_max));
    ui->lifelabel->setText(QString::number(life));
    time = time.addMSecs(-40);
    ui->timelabel->setText(time.toString("hh:mm:ss:zzz"));
    if(time.toString("hh:mm:ss:zzz")=="00:00:00:000"){
        timer.stop();
        time_1->stop();
        if(score>=score_0&&life>0)
        {
            if(difficulty<3)
            {
                this->close();
                Store *s=new Store;
                s->send_life(life);
                s->send_life_max(life_max);
                s->send_score(score);
                s->send_freeze_total(freeze_total);
                s->send_bomb_total(bomb_total);
                s->set_price();
                s->show();
            }
            if(difficulty>=3)
            {
                difficulty=-1;
                this->close();
                Congratulation *c=new Congratulation;
                c->show();
            }
        }
        else
        {
            this->close();
            End *e=new End;
            e->send_score(score);
            e->show();
        }

    }


}
//靶子
CombatScreen::~CombatScreen()
{
    delete ui;
}


void CombatScreen::build_kun()
{
    ikun = new target(this);
    IKUNS.append(ikun);
    ikun->combat_screen=this;
}


void CombatScreen::keyPressEvent(QKeyEvent *event){
    if((event->modifiers()& Qt::ControlModifier) != 0 && event->key()==Qt::Key_P){//Pause
        timer.stop();
        time_1->stop();

        int size=IKUNS.size();
        for(int i=0;i<size;++i){
            IKUNS[i]->stop_ttimer();
        }

        Pause *p=new Pause();
        p->show();
    }

    if(event->key()==Qt::Key_Q){//按键Q 甩技能1
        //技能1 冰冻
        //kun不动
        if(freeze_total>=1){
            ui->tricknumlabel1->setText(QString::number(freeze_total));//技能1 -=1
            freeze_total--;
            ui->tricknumlabel1->setText(QString::number(freeze_total));//技能1 -=1
            time_1->stop();
            int size=IKUNS.size();
            for(int i=0;i<size;++i){
                IKUNS[i]->stop_ttimer();
            }
            time.setHMS(0,0,3,0);
            ui->timelabel->setText("00:00:03:000");
        }
    }
}
void CombatScreen::on_bombButton_clicked()
{
    if(bomb_total>0){
        bomb_total--;
    }
}

void CombatScreen::on_freezeButton_clicked()
{
    if(freeze_total>0){
        freeze_total--;
    }
}
//暂停
void CombatScreen::on_pauseButtonC_clicked()
{
    timer.stop();
    time_1->stop();

    int size=IKUNS.size();
    for(int i=0;i<size;++i){
        IKUNS[i]->stop_ttimer();
    }

    Pause *p=new Pause();
    p->show();
}

void CombatScreen::score_increase(){
    score++;
    ui->scorelabel->setText(QString::number(score));
}

void CombatScreen::score_decrease(){
    if(score>0)score--;
    ui->scorelabel->setText(QString::number(score));
}

void CombatScreen::life_decrease(){
    if(life>0)life--;
    ui->lifelabel->setText(QString::number(life));
    if(life==0&&time.toString("hh:mm:ss:zzz")!="00:00:00:000"){
        life=-1;
        this->close();
        End *e = new End;
        e->send_score(score);
        e->show();
    }
}

void CombatScreen::send_score(int data)
{
    ui->scorelabel->setText(QString::number(data));
    score=data;
}

void CombatScreen::send_life(int data)
{
    ui->lifelabel->setText(QString::number(data));
    life=data;
}

void CombatScreen::send_life_max(int data)
{
    //ui->life_maxlabel->setText(QString::number(data));
    life_max=data;
}

void CombatScreen::send_freeze_total(int data)
{
    freeze_total=data;
}

void CombatScreen::send_bomb_total(int data)
{
    bomb_total=data;
}
/*
void CombatScreen::pause_restart(){
    timer.start();
    time_1->start();
    int size=IKUNS.size();
    for(int i=0;i<size;++i){
        IKUNS[i]->play_ttimer();
    }
}

void CombatScreen::pause_restart_1(){
    time_1->start();
}
*/


void CombatScreen::on_playButtonC_clicked()
{
    timer.start();
    time_1->start();

    int size=IKUNS.size();
    for(int i=0;i<size;++i){
        IKUNS[i]->play_ttimer();
    }

}


void CombatScreen::on_trickButton1C_clicked()
{
    //技能1 冰冻
    //kun不动
    if(freeze_total>=1){
        ui->tricknumlabel1->setText(QString::number(freeze_total));//技能1 -=1
        freeze_total--;
        ui->tricknumlabel1->setText(QString::number(freeze_total));//技能1 -=1
        time_1->stop();
        int size=IKUNS.size();
        for(int i=0;i<size;++i){
            IKUNS[i]->stop_ttimer();
        }
        time.setHMS(0,0,3,0);
        ui->timelabel->setText("00:00:03:000");
    }

    /*

    //技能定时器 3秒倒计时
    connect(&tricktimer,SIGNAL(timeout()),this,SLOT(tricktime1()));
    tricktime.setHMS(0,0,3,0);
    ui->tricktimelabel1->setText("00:00:03:000");
    tricktimer.start(40);
    if(tricktime.toString("hh:mm:ss:zzz")=="00:00:00:000"){
        tricktimer.stop();
        time_1->start();
        int size=IKUNS.size();
        for(int i=0;i<size;++i){
            IKUNS[i]->play_ttimer();
        }
    }
*/
}
/*
void CombatScreen::tricktime1(){
    if(freeze_total>=1){
        //类似暂停效果
        time_1->stop();
        int size=IKUNS.size();
        for(int i=0;i<size;++i){
            IKUNS[i]->stop_ttimer();
        }

        //trick计时器
        ui->tricknumlabel1->setText(QString::number(freeze_total));//技能1 -=1
        tricktime = tricktime.addMSecs(-40);
        ui->tricktimelabel1->setText(tricktime.toString("hh:mm:ss:zzz"));
        if(tricktime.toString("hh:mm:ss:zzz")=="00:00:00:000"){
            tricktimer.stop();
            freeze_total--;
            //继续跑
            time_1->start();
            int size=IKUNS.size();
            for(int i=0;i<size;++i){
                IKUNS[i]->play_ttimer();
            }
        }

    }

}
*/

void CombatScreen::on_trickButton2C_clicked()
{
    //技能2 金身炸弹



}
/*
void CombatScreen::tricktime2(){
    if(bomb_total>=1){
        bomb_total--;
        ui->tricknumlabel2->setText(QString::number(life_max));//技能2 -=1
        time = time.addMSecs(-40);
        ui->tricktimelabel2->setText(time.toString("hh:mm:ss:zzz"));
        if(time.toString("hh:mm:ss:zzz")=="00:00:00:000"){
            timer.stop();
        }
    }

}
*/
