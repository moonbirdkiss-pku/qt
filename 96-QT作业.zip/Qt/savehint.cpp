#include "savehint.h"
#include "ui_savehint.h"

saveHint::saveHint(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::saveHint)
{
    ui->setupUi(this);
}

saveHint::~saveHint()
{
    delete ui;
}

void saveHint::on_toolButton_clicked()
{
    this->close();
}

