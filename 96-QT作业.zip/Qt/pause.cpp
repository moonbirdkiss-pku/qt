#include <QProcess>
#include <QKeyEvent>
#include <QLabel>
#include "pause.h"
#include "ui_pause.h"
#include "combatscreen.h"
#include "mainmenu.h"
#include "savehint.h"
#include "ui_savehint.h"

Pause::Pause(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Pause)
{
    ui->setupUi(this);

}

Pause::~Pause()
{
    delete ui;
}

void Pause::keyPressEvent(QKeyEvent *event){
    if((event->modifiers()& Qt::ControlModifier) != 0 && event->key()==Qt::Key_E){//Exit (这个功能直接esc 是一样的)
        this->close();
        qApp->exit();
    }

    if((event->modifiers()& Qt::ControlModifier) != 0 && event->key()==Qt::Key_B){//Back to main menu
        this->close();
        MainMenu *mm=new MainMenu();
        mm->show();
    }
    if((event->modifiers()& Qt::ControlModifier) != 0 && event->key()==Qt::Key_S){//Save
        //存档
        saveHint *dialog = new saveHint(this);
        dialog->setModal(true);
        dialog->show();
    }

}



void Pause::on_continueButtonC_clicked()
{
    this->close();
    CombatScreen *cs=new CombatScreen();
    cs->show();

}

void Pause::on_returnButtonC_clicked()
{
    this->close();
    MainMenu *mm=new MainMenu();
    mm->show();
}


void Pause::on_exitButtonC_clicked()
{
    this->close();
    qApp->exit();
}
