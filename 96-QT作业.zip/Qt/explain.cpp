#include "explain.h"
#include "ui_explain.h"
#include "explain_rule.h"
#include "explain_operation.h"
#include "mainmenu.h"
#include "ui_mainmenu.h"

Explain::Explain(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Explain)
{
    ui->setupUi(this);
}

Explain::~Explain()
{
    delete ui;
}

void Explain::on_ruleButtonC_clicked()
{
    this->close();
    Explain_Rule *er=new Explain_Rule();
    er->show();
}


void Explain::on_keyButtonC_clicked()
{
    this->close();
    Explain_Operation *eo=new Explain_Operation();
    eo->show();
}


void Explain::on_returnButtonC_clicked()
{
    this->close();
    MainMenu *mm = new MainMenu();
    mm->show();
}

