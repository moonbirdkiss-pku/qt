#ifndef PAUSE_H
#define PAUSE_H

#include <QDialog>
#include <QKeyEvent>
#include <QLabel>
namespace Ui {
class Pause;
}

class Pause : public QDialog
{
    Q_OBJECT

public:
    explicit Pause(QWidget *parent = nullptr);
    ~Pause();

private:
    void keyPressEvent(QKeyEvent *event);

private slots:
    void on_continueButtonC_clicked();

    void on_returnButtonC_clicked();

    void on_exitButtonC_clicked();

private:
    Ui::Pause *ui;

};

#endif // PAUSE_H
