#include "widget.h"
#include "end.h"
#include"mainmenu.h"
#include "store.h"
#include "startmenu.h"
#include "ui_startmenu.h"
#include <QApplication>
#include <QLocale>
#include <QTranslator>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages) {
        const QString baseName = "Qt_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            a.installTranslator(&translator);
            break;
        }
    }
    startMenu *sm = new startMenu();
    sm->show();

    return a.exec();
}
