#ifndef SAVEHINT_H
#define SAVEHINT_H

#include <QDialog>

namespace Ui {
class saveHint;
}

class saveHint : public QDialog
{
    Q_OBJECT

public:
    explicit saveHint(QWidget *parent = nullptr);
    ~saveHint();

private slots:
    void on_toolButton_clicked();

private:
    Ui::saveHint *ui;
};

#endif // SAVEHINT_H
