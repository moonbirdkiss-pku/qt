#ifndef LOAD_H
#define LOAD_H

#include <QDialog>
#include<QTextStream>

namespace Ui {
class load;
}

class load : public QDialog
{
    Q_OBJECT

public:
    explicit load(QWidget *parent = nullptr);
    ~load();

private slots:
    void on_loadButton1C_clicked();

    void on_loadButton2C_clicked();

    void on_loadButton3C_clicked();

    void on_returnButtonC_clicked();

private:
    Ui::load *ui;
};

#endif // LOAD_H
