#ifndef SAVE_H
#define SAVE_H

#include <QDialog>
#include<QTextStream>

namespace Ui {
class Save;
}

class Save : public QDialog
{
    Q_OBJECT

public:
    explicit Save(QWidget *parent = nullptr);
    ~Save();
    int diffi=1;
    int score=0;
    int life=5;
    int life_max=5;
    int bomb_total=0;
    int freeze_total=0;
    QTextStream out;
    void Data_Save(int pos);

private slots:
    void on_returnButtonC_clicked();

    void on_saveButton1_clicked();

    void on_saveButton2_clicked();

    void on_saveButton3_clicked();

private:
    Ui::Save *ui;
};

#endif // SAVE_H
