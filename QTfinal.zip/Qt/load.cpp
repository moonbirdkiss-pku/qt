#include "load.h"
#include "ui_load.h"
#include "mainmenu.h"
#include <QFile>
#include <QDir>
#include <QString>
#include <QDebug>
#include <QTextStream>
#include "combatscreen.h"
extern int difficulty;
load::load(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::load)
{
    ui->setupUi(this);
}

load::~load()
{
    delete ui;
}

void load::on_loadButton1C_clicked()
{
    //读档1
    CombatScreen *cs=new CombatScreen();
    QFile file("save1.txt");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        return;
    }
    QTextStream in(&file);
    QString line = in.readLine();
    line = in.readLine();
    cs->life=line.toInt();
    line = in.readLine();
    cs->life_max=line.toInt();
    line = in.readLine();
    cs->bomb_total=line.toInt();
    line = in.readLine();
    cs->freeze_total=line.toInt();
    line = in.readLine();
    cs->score=line.toInt();
    file.close();
    this->close();
    cs->show();
}


void load::on_loadButton2C_clicked()
{
    //读档2
    CombatScreen *cs=new CombatScreen();
    QFile file("save2.txt");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        return;
    }
    QTextStream in(&file);
    QString line = in.readLine();
    line = in.readLine();
    cs->life=line.toInt();
    line = in.readLine();
    cs->life_max=line.toInt();
    line = in.readLine();
    cs->bomb_total=line.toInt();
    line = in.readLine();
    cs->freeze_total=line.toInt();
    line = in.readLine();
    cs->score=line.toInt();
    file.close();
    this->close();
    cs->show();
}


void load::on_loadButton3C_clicked()
{
    //读档3
    CombatScreen *cs=new CombatScreen();
    QFile file("save3.txt");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        return;
    }
    QTextStream in(&file);
    QString line = in.readLine();
    line = in.readLine();
    cs->life=line.toInt();
    line = in.readLine();
    cs->life_max=line.toInt();
    line = in.readLine();
    cs->bomb_total=line.toInt();
    line = in.readLine();
    cs->freeze_total=line.toInt();
    line = in.readLine();
    cs->score=line.toInt();
    file.close();
    this->close();
    cs->show();
}


void load::on_returnButtonC_clicked()
{
    this->close();
    MainMenu *mm=new MainMenu();
    mm->show();
}

