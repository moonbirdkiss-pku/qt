#include "target.h"
#include "combatscreen.h"
#include <QTime>
extern int difficulty;

target::target(QWidget *parent) :
    QLabel(parent)
{
    ttime = new QTimer();
    connect(ttime,SIGNAL(timeout()),this,SLOT(ttimer()));
    if(difficulty == 0||difficulty == 1)
    {
        setGeometry(x()+10,rand() % 400+100, 100,100 );
        setScaledContents(true);
        QImage res(":/new/prefix1/image/CombatScreen/normaltarget.gif");
        setPixmap(QPixmap::fromImage(res));
        if(tmp<6)speed = 50;
        if(tmp == 7||tmp == 8)speed = 40;
        if(tmp ==9)speed = 30;
    }
    if(difficulty ==2)
    {
        if(tmp1==0)
        {
            setGeometry(x()+10,rand() % 400+100, 100,100 );
            setScaledContents(true);
            QImage res(":/new/prefix1/image/CombatScreen/normaltarget.gif");
            setPixmap(QPixmap::fromImage(res));
            if(tmp<6)speed = 50;
            if(tmp == 7||tmp == 8)speed = 40;
            if(tmp ==9)speed = 30;
        }
        if(tmp1==1)
        {
            setGeometry(x()+790,rand() % 400+100, 100,100 );
            setScaledContents(true);
            QImage res(":/new/prefix1/image/CombatScreen/normaltarget.gif");
            setPixmap(QPixmap::fromImage(res));
            if(tmp<6)speed = 50;
            if(tmp == 7||tmp == 8)speed = 40;
            if(tmp ==9)speed = 30;
        }
    }
    if(difficulty==3)
    {
        if(tmp2==0)
        {
            setGeometry(x()+10,rand() % 400+100, 100,100 );
            setScaledContents(true);
            QImage res(":/new/prefix1/image/CombatScreen/normaltarget.gif");
            setPixmap(QPixmap::fromImage(res));
            if(tmp<6)speed = 50;
            if(tmp == 7||tmp == 8)speed = 40;
            if(tmp ==9)speed = 30;
        }
        if(tmp2==1)
        {
            setGeometry(x()+790,rand() % 400+100, 100,100 );
            setScaledContents(true);
            QImage res(":/new/prefix1/image/CombatScreen/normaltarget.gif");
            setPixmap(QPixmap::fromImage(res));
            if(tmp<6)speed = 50;
            if(tmp == 7||tmp == 8)speed = 40;
            if(tmp ==9)speed = 30;
        }
        if(tmp2==2)
        {
            setGeometry(rand()%700,100+y(), 100,100 );
            setScaledContents(true);
            QImage res(":/new/prefix1/image/CombatScreen/normaltarget.gif");
            setPixmap(QPixmap::fromImage(res));
            if(tmp<6)speed = 50;
            if(tmp == 7||tmp == 8)speed = 40;
            if(tmp ==9)speed = 30;
        }
        if(tmp2==3)
        {
            setGeometry(rand()%700,600+y(), 100,100 );
            setScaledContents(true);
            QImage res(":/new/prefix1/image/CombatScreen/normaltarget.gif");
            setPixmap(QPixmap::fromImage(res));
            if(tmp<6)speed = 50;
            if(tmp == 7||tmp == 8)speed = 40;
            if(tmp ==9)speed = 30;
        }
    }
    show();
    ttime->start(speed);
}

void target::mousePressEvent(QMouseEvent *event)
{
    combat_screen->score_increase();
    hide();
    ttime->stop();
}

void target::ttimer()
{
    if(difficulty==0||difficulty==1)
    {
        setGeometry(x() + 10, y(), 100 , 100);
        if(x()>801)
        {
            combat_screen->score_decrease();
            combat_screen->life_decrease();
            hide();
            ttime->stop();
        }
    }
    if(difficulty==2)
    {
        if(tmp1==0)
        {
            setGeometry(x() + 10, y(), 100 , 100);
            if(x()>801)
            {
                combat_screen->score_decrease();
                combat_screen->life_decrease();
                hide();
                ttime->stop();
            }
        }
        if(tmp1==1)
        {
            setGeometry(x() - 10, y(), 100 , 100);
            if(x()<1)
            {
                combat_screen->score_decrease();
                combat_screen->life_decrease();
                hide();
                ttime->stop();
            }
        }
    }
    if(difficulty==3)
    {
        if(tmp2==0)
        {
            setGeometry(x() + 10, y(), 100 , 100);
            if(x()>801)
            {
                combat_screen->score_decrease();
                combat_screen->life_decrease();
                hide();
                ttime->stop();
            }
        }
        if(tmp2==1)
        {
            setGeometry(x() - 10, y(), 100 , 100);
            if(x()<1)
            {
                combat_screen->score_decrease();
                combat_screen->life_decrease();
                hide();
                ttime->stop();
            }
        }
        if(tmp2==2)
        {
            setGeometry(x(), y()+10, 100 , 100);
            if(x()>601)
            {
                combat_screen->score_decrease();
                combat_screen->life_decrease();
                hide();
                ttime->stop();
            }
        }
        if(tmp2==3)
        {
            setGeometry(x(), y()-10, 100 , 100);
            if(y()<100)
            {
                combat_screen->score_decrease();
                combat_screen->life_decrease();
                hide();
                ttime->stop();
            }
        }
    }
}


void target::stop_ttimer(){
    ttime->stop();
}
void target::play_ttimer(){
    ttime->start();
}
