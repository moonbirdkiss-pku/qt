#ifndef EXPLAIN_RULE_H
#define EXPLAIN_RULE_H

#include <QDialog>

namespace Ui {
class Explain_Rule;
}

class Explain_Rule : public QDialog
{
    Q_OBJECT

public:
    explicit Explain_Rule(QWidget *parent = nullptr);
    ~Explain_Rule();

private slots:
    void on_returnButtonC_clicked();

private:
    Ui::Explain_Rule *ui;
};

#endif // EXPLAIN_RULE_H
