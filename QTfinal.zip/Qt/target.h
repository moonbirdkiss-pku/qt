#ifndef TARGET_H
#define TARGET_H
#include <QWidget>
#include <QLabel>
#include <QTimer>
#include <QMouseEvent>
#include <random>

class CombatScreen;

class target : public QLabel
{
    Q_OBJECT
public:
    int speed=50;
    int tmp=rand()%10;
    int tmp1=rand()%2;
    int tmp2=rand()%4;
    explicit target(QWidget *parent = 0);
    void mousePressEvent(QMouseEvent *event);
    CombatScreen *combat_screen;
    QTimer *ttime;
    void stop_ttimer();
    void play_ttimer();

signals:

public slots:
    void ttimer();



private:

};

#endif // TARGET_H
