#include "mainmenu_eng.h"
#include "ui_mainmenu_eng.h"
#include "startmenu.h"

MainMenu_eng::MainMenu_eng(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MainMenu_eng)
{
    ui->setupUi(this);
}

MainMenu_eng::~MainMenu_eng()
{
    delete ui;
}

void MainMenu_eng::on_pushButton_2_clicked()
{
    this->close();
    startMenu *sm=new startMenu();
    sm->show();
}

