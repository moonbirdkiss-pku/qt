#include "save.h"
#include "ui_save.h"
#include "mainmenu.h"
#include "savehint.h"
#include <QFile>
#include <QDir>
#include <QString>
#include <QTextStream>

Save::Save(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Save)
{
    ui->setupUi(this);
}

Save::~Save()
{
    delete ui;
}

void Save::on_returnButtonC_clicked()
{
    this->close();
    MainMenu *mm=new MainMenu();
    mm->show();
}


void Save::on_saveButton1_clicked()
{
    //存档1

    QString fileName = "save1.txt";
    QFile file(fileName);
    if(file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream in(&file);
        in<<diffi;
        in<<'\n';
        in<<life;
        in<<'\n';
        in<<life_max;
        in<<'\n';
        in<<bomb_total;
        in<<'\n';
        in<<freeze_total;
        in<<'\n';
        in<<score;
        in<<'\n';
        file.close();
        saveHint *sh=new saveHint();
        sh->show();
    }
    else {
        qWarning() << "Failed to open file:" ;
    }

}


void Save::on_saveButton2_clicked()
{
    //存档2
    QString fileName = "save2.txt";
    QFile file(fileName);
    if(file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream in(&file);
        in<<diffi;
        in<<'\n';
        in<<life;
        in<<'\n';
        in<<life_max;
        in<<'\n';
        in<<bomb_total;
        in<<'\n';
        in<<freeze_total;
        in<<'\n';
        in<<score;
        in<<'\n';
        file.close();
        saveHint *sh=new saveHint();
        sh->show();
    }
    else {
        qWarning() << "Failed to open file:" ;
    }
}


void Save::on_saveButton3_clicked()
{
    //存档3
    QString fileName = "save3.txt";
    QFile file(fileName);
    if(file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream in(&file);
        in<<diffi;
        in<<'\n';
        in<<life;
        in<<'\n';
        in<<life_max;
        in<<'\n';
        in<<bomb_total;
        in<<'\n';
        in<<freeze_total;
        in<<'\n';
        in<<score;
        in<<'\n';
        file.close();
        saveHint *sh=new saveHint();
        sh->show();
    }
    else {
        qWarning() << "Failed to open file:" ;
    }
}

