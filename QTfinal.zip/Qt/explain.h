#ifndef EXPLAIN_H
#define EXPLAIN_H

#include <QDialog>

namespace Ui {
class Explain;
}

class Explain : public QDialog
{
    Q_OBJECT

public:
    explicit Explain(QWidget *parent = nullptr);
    ~Explain();

private slots:
    void on_ruleButtonC_clicked();

    void on_keyButtonC_clicked();

    void on_returnButtonC_clicked();

private:
    Ui::Explain *ui;
};

#endif // EXPLAIN_H
