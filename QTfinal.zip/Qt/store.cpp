#include "store.h"
#include "ui_store.h"
#include"combatscreen.h"
#include"save.h"

extern int difficulty;

Store::Store(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Store)
{
    ui->setupUi(this);
}

Store::~Store()
{
    delete ui;
}


void Store::on_contiueButtonC_clicked()
{
    this->close();
    CombatScreen *cs=new CombatScreen();
    cs->send_life(life);
    cs->send_life_max(life_max);
    cs->send_score(score);
    cs->send_freeze_total(freeze_total);
    cs->send_bomb_total(bomb_total);
    cs->show();
}

void Store::send_life(int data)
{
    ui->lifelabel->setText(QString::number(data));
    life = data;
}

void Store::send_life_max(int data)
{
    ui->life_maxlabel->setText(QString::number(data));
    life_max = data;
}

void Store::send_score(int data)
{
    ui->scorelabel->setText(QString::number(data));
    score = data;
}


void Store::send_bomb_total(int data)
{
    bomb_total = data;
}

void Store::send_freeze_total(int data)
{
    freeze_total = data;
}

void Store::set_price()
{
    int tmp=score/8;
    if(tmp==1)tmp=2;
    HPrecoverporp_price=tmp+rand()%tmp;
    HPplusprop_price=tmp+rand()%tmp;
    freeze_price=tmp+rand()%tmp;
    bomb_price=tmp+rand()%tmp;
    ui->freezepriceButton->setText(QString::number(freeze_price));

    ui->HPRecoverPrice->setText(QString::number(HPrecoverporp_price));
    ui->HPpluspropPrice->setText(QString::number(HPplusprop_price));
}

void Store::on_HPpluspropButtonC_clicked()
{
    if(score>=HPplusprop_price)
    {
        life_max+=5;
        score-=HPplusprop_price;
        ui->scorelabel->setText(QString::number(score));
        ui->life_maxlabel->setText(QString::number(life_max));
    }
    //Hp max+=5
}


void Store::on_HPrecoverypropButtonC_clicked()
{
    if(score>=HPrecoverporp_price)
    {
        if(life+5<=life_max)
        {
            life+=5;
        }
        else life=life_max;
        score-=HPrecoverporp_price;
        ui->scorelabel->setText(QString::number(score));
        ui->lifelabel->setText(QString::number(life));
    }
    //Hp +=5
}

void Store::on_freezepriceButton_clicked()
{
    if(score>=freeze_price)
    {
        freeze_total++;
        score-=freeze_price;
        ui->scorelabel->setText(QString::number(score));
        ui->freezeTime->setText(QString::number(freeze_total));
    }
}


void Store::on_saveButton_clicked()
{
    Save *sa=new Save();
    sa->diffi=difficulty;
    //qDebug()<<sa->diffi<<" "<<difficulty;
    sa->life=life;
    sa->life_max=life_max;
    sa->bomb_total=bomb_total;
    sa->freeze_total=freeze_total;
    sa->score=score;
    this->close();
    sa->show();
}

