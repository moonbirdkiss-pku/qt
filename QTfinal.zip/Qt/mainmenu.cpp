#include "mainmenu.h"
#include "ui_mainmenu.h"
#include "combatscreen.h"
#include "save.h"
#include "explain.h"
#include "startmenu.h"
#include "ui_startmenu.h"
#include "load.h"

MainMenu::MainMenu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MainMenu)
{
    ui->setupUi(this);
}

MainMenu::~MainMenu()
{
    delete ui;
}
void MainMenu::keyPressEvent(QKeyEvent *event){
    if((event->modifiers()& Qt::ControlModifier) != 0 && event->key()==Qt::Key_I){//Introduction
        this->hide();
        Explain *p=new Explain();
        p->show();
    }
}

void MainMenu::on_startButtonC_clicked()
{
    this->hide();
    CombatScreen *cs=new CombatScreen();
    cs->show();
}


void MainMenu::on_saveButtonC_clicked()
{
    this->hide();
    load *l=new load();
    l->show();
}


void MainMenu::on_introButtonC_clicked()
{
    this->hide();
    Explain *e=new Explain();
    e->show();
}


void MainMenu::on_exitButtonC_clicked()
{
    this->close();
    qApp->quit();
}


void MainMenu::on_returnButtonC_clicked()
{
    this->close();
    startMenu *sm = new startMenu();
    sm->show();
}

